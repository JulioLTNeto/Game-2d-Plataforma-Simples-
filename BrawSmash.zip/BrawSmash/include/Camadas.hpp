#pragma once
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

#include "Entidade.hpp"
class Camadas:Entidade{
public:
	Camadas();

};