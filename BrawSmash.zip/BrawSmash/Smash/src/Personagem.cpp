#include "Personagem.hpp"
#include <iostream>

using namespace std;

Personagem::Personagem(Vector2f p_pos, SDL_Texture* p_tex, float p_w, float p_h, int p_camada, bool p_tangivel, int p_vida, float p_velocidade):Entidade(p_pos, p_tex, p_w, p_h, p_camada, p_tangivel){
	vida = p_vida;
	velocidade = p_velocidade;
	currentTime = 0;
	lastTime = 0;

	lastTimePulo = 0;

	atingiuBordaLeft = false;
	atingiuBordaRight = false;

	i = 0;
	alturaPulo = 0;
	emPulo = false;
	temAlgo = false;
	aceleracao = 0.007;
	tempoQueda = 0;
	tempoQ = 0;

	quantidadePulo = 2;
	podeEntrar = true;
	tempo = 0;

	alturaInicial = 0;
	velocidadeVerticalInicial = 1.5;
	ultimaAltura = 0;
	velocidadeBackup = velocidade;
	colisaoL = false;
	colisaoR = false;

	tempoDecorrido = 0;
	caiu = false;
	caiuNaColisao = false;
}
void Personagem::moverPersonagem(SDL_Event evento, vector<Entidade>* entidades){
	currentTime = SDL_GetTicks();
	//Gravidade

	if(temAlgo == false && currentTime >= tempoQueda+10 && emPulo == false){
		Vector2f posicaoPersonagem = getPos();
		posicaoPersonagem.y = posicaoPersonagem.y+(velocidadeVerticalInicial*tempo)-((aceleracao*(tempo*tempo))/2);
		setPos(posicaoPersonagem);
		tempoQueda = currentTime;
		tempo++;
		i = 1;
		caiu = true;
		cout << "Caindo" << endl;
	}

	caiuNaColisao = false;
	Entidade* fundo = &(*entidades)[0];
	currentTime = SDL_GetTicks();
	Vector2f frameFundo = (*fundo).getPos();
	for(Entidade& entity:*entidades){
		Vector2f posicaoEntidade = entity.getPos();
		SDL_Rect sub = entity.getCurrentFrame();

		if(entity.eTangivel() == 1 || entity.eTangivel() == 2){
			
			Vector2f posicaoPersonagem = getPos();
			if(colisao(posicaoPersonagem.x, posicaoEntidade.x, posicaoPersonagem.y, posicaoEntidade.y, 110, sub.w, 110, sub.h)){
				if(i == 1 && emPulo == false){
					i = 0;
					alturaPulo = 0;
					tempo = 0;
					quantidadePulo = 2;
					podeEntrar = true;
					temAlgo = true;
				}
				if(caiu == true){
					caiu = false;
					posicaoPersonagem.y = posicaoEntidade.y-100;
				}
				setPos(posicaoPersonagem);
				caiuNaColisao = true;
			}
			
		}

	}

	if(evento.type == SDL_KEYDOWN){
				if(evento.key.keysym.sym == SDLK_RIGHT){
					Vector2f auxiliar = getPos();
					if(auxiliar.x + velocidade < (1280-110)){
						colisaoL = false;
						cout << "RIGHT" << endl;
						tempoDecorrido = currentTime;
						if(auxiliar.x <= (1280/2) || (frameFundo.x-0.1 <= -1280)){
							auxiliar.x = auxiliar.x+velocidade;
							setPos(auxiliar);
							if(frameFundo.x-0.1 <= -1280){
								atingiuBordaRight = true;
							}
						}
						else{
							atingiuBordaRight = true;
							int cont = 0;
							for(Entidade& en: *entidades){
								Vector2f posicao = en.getPos();
								if(en.getCamada() == 0){
									posicao.x = posicao.x-0.1;
								}else if(en.getCamada() == 1){
									posicao.x = posicao.x-(velocidade/4);
								}else if(en.getCamada() == 2){
									posicao.x = posicao.x-velocidade;
								}
								en.setPos(posicao);
								cont++;
							}
						}
						if(currentTime > lastTime+100){
							SDL_Rect aux = getCurrentFrame();
							
							if((aux.x)+110 > 440){
								if(aux.y == 110){
									aux.y = 0;
								}
								else{
									aux.y = 110;
								}
								aux.x = -110;
							}
							setX((aux.x)+110);
							lastTime = currentTime;
						}
					}
				}
				
				if(evento.key.keysym.sym == SDLK_DOWN){
				}
				if(evento.key.keysym.sym == SDLK_LEFT){
					Vector2f auxiliar = getPos();
					if(auxiliar.x - velocidade > (0)){
						colisaoR = false;
						cout << "LEFT" << endl;
						tempoDecorrido = currentTime;
						if(auxiliar.x >= (1280/2) || frameFundo.x+0.1 >= 0){
							auxiliar.x = auxiliar.x-velocidade;
							setPos(auxiliar);
							if(frameFundo.x+0.1 >= 0){
								atingiuBordaLeft = true;
							}
						}
						else{
							int cont = 0;
							for(Entidade& en: *entidades){
								Vector2f posicao = en.getPos();
								if(en.getCamada() == 0){
									posicao.x = posicao.x+0.1;
								}else if(en.getCamada() == 1){
									posicao.x = posicao.x+(velocidade/4);
								}else if(en.getCamada() == 2){
									posicao.x = posicao.x+velocidade;
								}
								en.setPos(posicao);
								cont++;
							}
						}
						if(currentTime > lastTime+100){
							SDL_Rect aux = getCurrentFrame();
							if((aux.x)-110 < 0){
								if(aux.y == 110){
									aux.y = 0;
								}
								else{
									aux.y = 110;
								}
								aux.x = 440;
							}
							setX((aux.x)-109);
							lastTime = currentTime;
						}
					}
				}
			}
	
	if(caiuNaColisao){
		//cout << "caiuNaColisao" << endl;
	}
	if(caiuNaColisao == false){
		temAlgo = false;
	}

	if(evento.type == SDL_KEYDOWN){
		Vector2f posicaoPersonagem = getPos();
		if(evento.key.keysym.sym == SDLK_UP){
			if(quantidadePulo > 0 && podeEntrar == true){
				emPulo = true;
				quantidadePulo--;
				alturaInicial = posicaoPersonagem.y;
				alturaPulo = 0;
				tempo = 0;
				cout << "Pode Entrar" << endl;
			}
		}
		if(alturaPulo > 5){
			podeEntrar = true;
		}
	}
	puloPersonagem();
	
}
int Personagem::getVida(){
	return vida;
}
void Personagem::setVida(int v){
	vida = v;
}
void Personagem::puloPersonagem(){
		currentTime = SDL_GetTicks();
		if(emPulo == true){
			i = 0;
				Vector2f pos = getPos();
				ultimaAltura = pos.y;
				pos.y = alturaInicial - (velocidadeVerticalInicial*tempo)+((aceleracao*(tempo*tempo))/2);
				alturaPulo = alturaPulo + 0.2;
				tempo++;
				podeEntrar = false;
				setPos(pos);
				if(ultimaAltura < pos.y){
					emPulo = false;
					i = 1;
					tempo = 0;
				}
			
			lastTimePulo = currentTime;
		}
}
bool Personagem::colisao(float x1, float x2, float y1, float y2, float w1, float w2, float h1, float h2){
	if ((x1 < (x2 + w2)) && ((x1 + w1) > x2) && (y1 < (y2 + h2)) && ((y1 + h1) > y2)) {
		return true;
	}
	return false;
}

bool Personagem::colisaoLeft(float x1, float x2, float y1, float y2, float w1, float w2, float h1, float h2){
	if ((x2 <= (x1)) && ((x2 + w2) > x1) && (((y2 > y1) && (y2 < (y1+h1))) || ((y2<y1)&&((y2+h2)>y)))) {
		cout << "colidiuLeft" << endl;
		return true;
	}
	cout << "naoColidiuLeft" << endl;
	return false;
}

bool Personagem::colisaoRight(float x1, float x2, float y1, float y2, float w1, float w2, float h1, float h2){
	if ((x2 <= (x1+w1)) && ((x2 + w2) > (x1+w1)) && (((y2 > y1) && (y2 < (y1+h1))) || ((y2<y1)&&((y2+h2)>y)))) {
		cout << "colidiuRight" << endl;
		return true;
	}
	cout << "naoColidiuRight" << endl;
	return false;
}