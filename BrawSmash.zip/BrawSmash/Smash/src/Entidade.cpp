#include "Entidade.hpp"
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

#include <iostream>
using namespace std;

Entidade::Entidade(Vector2f p_pos, SDL_Texture* p_tex, float p_w, float p_h, int p_camada, int p_tangivel):pos(p_pos), tex(p_tex), camada(p_camada), tangivel(p_tangivel){
	currentFrame.x = 0;
	currentFrame.y = 0;
	currentFrame.w = p_w;
	currentFrame.h = p_h;
}

void Entidade::setX(float x){
	currentFrame.x = x;
}

void Entidade::setY(float y){
	currentFrame.y = y;
}

int Entidade::getCamada(){
	return camada;
}

int Entidade::eTangivel(){
	return tangivel;
}

void Entidade::setPos(Vector2f p){
	pos = p;
}

SDL_Texture* Entidade::getTex(){
	return tex;
}
SDL_Rect Entidade::getCurrentFrame(){
	return currentFrame;
}