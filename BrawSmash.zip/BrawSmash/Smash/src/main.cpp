#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <iostream>
#include <string>
#include <vector>

using namespace std;
#include "MostrarTela.hpp"
#include "Entidade.hpp"
#include "Math.hpp"
#include "Mapa01.hpp"

int main(int argc, char* args[]){
	if(SDL_Init(SDL_INIT_VIDEO) > 0){
		cout<< "SDL_INIT Fail Error:" << SDL_GetError()<< endl;
	}
	if(!(IMG_Init(IMG_INIT_PNG))){
		cout << "IMG_Init fail Error:" << SDL_GetError() << endl;
	}

	vector<Entidade> entidades;

	MostrarTela window("BrawSmash", 1280, 700);
	bool executando = true;

	SDL_Texture* textura = window.loadTexture("res/entidades/personagem02.jpg");
	SDL_Texture* textura_fundo = window.loadTexture("res/fundo.jpg");
	SDL_Texture* textura_logo = window.loadTexture("res/logo.png");

	Entidade fundo = Entidade(Vector2f(0,0), textura_fundo, 1280, 700, 0, 0);
	entidades.push_back(fundo);
	Entidade logo = Entidade(Vector2f(440,50), textura_logo, 300, 300, 0, 0); 
	entidades.push_back(logo);

	SDL_Event evento;
	while(executando){
		while(SDL_PollEvent(&evento)){
			if(evento.type == SDL_QUIT){
				executando = false;
			}
			if(evento.type == SDL_KEYDOWN && evento.key.keysym.sym == SDLK_ESCAPE){
				window.cleanUp();
				Mapa01 mapa = Mapa01();
				mapa.mostrarTela();
			}
		}

		window.clear();
		for(Entidade& e: entidades){
			window.render(e);
		}

		window.display();
	}
	window.cleanUp();
	SDL_Quit();
	return 0;
}