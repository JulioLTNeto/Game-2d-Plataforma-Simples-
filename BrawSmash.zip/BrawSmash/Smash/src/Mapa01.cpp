#include "Mapa01.hpp"
#include <iostream>
#define ALTURA_PADRAO_TOCO 480
#define alturaPadraoArvores 250

using namespace std;

Mapa01::Mapa01(){
	window = MostrarTela("Mapa01", 1280, 700);
}

void Mapa01::adcionarVetor(Entidade e){
	v.push_back(e);
}
vector<Entidade>* Mapa01::getEntidades(){
	return &v;
}

void Mapa01::gerarMapa(){
	//Carrega as texturas
	SDL_Texture* textura_fundo = window.loadTexture("res/fundoMapa01.jpg");
	SDL_Texture* textura_plataforma_grande = window.loadTexture("res/itens/plataforma-grandeS.png");
	SDL_Texture* textura_plataforma_left = window.loadTexture("res/itens/gramaSemFundoLeft.png");
	SDL_Texture* textura_plataforma_right = window.loadTexture("res/itens/gramaSemFundoRight.png");
	SDL_Texture* textura_plataforma = window.loadTexture("res/itens/gramaSemFundo.png");

	Entidade fundo = Entidade(Vector2f(0,0), textura_fundo, 1280, 700, 0, 0);
	Entidade plataforma_grande = Entidade(Vector2f(440,300), textura_plataforma_grande, 400, 300, 1, 1);
	Entidade plataforma_left = Entidade(Vector2f(900,200), textura_plataforma_left, 150, 50, 1, 1);
	Entidade plataforma_right = Entidade(Vector2f(1050,200), textura_plataforma_right, 150, 50, 1, 1);

	v.push_back(fundo);
	v.push_back(plataforma_grande);
	v.push_back(plataforma_left);
	v.push_back(plataforma_right);

}

int Mapa01::mostrarTela(){
	gerarMapa();
	SDL_Event evento;
	bool executando = true;
	while(executando){
		while(SDL_PollEvent(&evento)){
			if(evento.type == SDL_QUIT){
				executando = false;
			}
			if(evento.type == SDL_KEYDOWN && evento.key.keysym.sym == SDLK_ESCAPE){
				executando = false;
			}
		}

		window.clear();

		for(Entidade& e: v){
			window.render(e);
		}

		window.display();
	}
	window.cleanUp();
}