#include "Mapa02.hpp"
#include <iostream>
#define ALTURA_PADRAO_TOCO 480
#define alturaPadraoArvores 250

using namespace std;

Mapa02::Mapa02(){
}
void Mapa02::adcionarVetor(Entidade e){
	v.push_back(e);
}
vector<Entidade>* Mapa02::getEntidades(){
	return &v;
}

void Mapa02::gerarMapa(MostrarTela window){
	//Carrega as texturas
	SDL_Texture* textura_fundo = window.loadTexture("res/BG/BG2.png");
	SDL_Texture* textura_logo = window.loadTexture("res/logo.png");
	SDL_Texture* textura_mapa = window.loadTexture("res/mapa1.png");
	SDL_Texture* textura_selecao = window.loadTexture("res/selecao.png");

	Entidade fundo = Entidade(Vector2f(-100,0), textura_fundo, 1880, 700, 0, 0);
	v.push_back(fundo);

	Entidade logo = Entidade(Vector2f(400,0), textura_logo, 400, 300, 2, 0);
	v.push_back(logo);
	Entidade mapa1 = Entidade(Vector2f(250,350), textura_mapa, 100, 100, 2, 0);
	v.push_back(mapa1);
	Entidade selecao = Entidade(Vector2f(250,350), textura_selecao, 100, 100, 2, 0);
	v.push_back(selecao);

}
