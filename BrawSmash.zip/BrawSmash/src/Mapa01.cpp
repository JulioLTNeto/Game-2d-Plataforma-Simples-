#include "Mapa01.hpp"
#include <iostream>
#define ALTURA_PADRAO_TOCO 480
#define alturaPadraoArvores 250

using namespace std;

Mapa01::Mapa01(){
	window = MostrarTela("BrawSmash-Mapa01", 1280, 700);
}

void Mapa01::adcionarVetor(Entidade e){
	v.push_back(e);
}
vector<Entidade>* Mapa01::getEntidades(){
	return &v;
}

void Mapa01::gerarMapa(){
	
	//Carrega as texturas
	SDL_Texture* textura_fundo = window.loadTexture("res/BG/BG.png");
	SDL_Texture* textura_grama13 = window.loadTexture("res/Tiles/gramaSemFundoLeft.png");
	SDL_Texture* textura_grama14 = window.loadTexture("res/Tiles/gramaSemFundo.png");
	SDL_Texture* textura_grama15 = window.loadTexture("res/Tiles/gramaSemFundoRight.png");
	SDL_Texture* textura_arvore03 = window.loadTexture("res/Object/Tree_3.png");
	SDL_Texture* textura_arvore02 = window.loadTexture("res/Object/Tree_2.png");
	SDL_Texture* textura_arvore01 = window.loadTexture("res/Object/Tree_1.png");
	SDL_Texture* textura_arbusto01 = window.loadTexture("res/Object/Bush (1).png");
	SDL_Texture* textura_arbusto02 = window.loadTexture("res/Object/Bush (2).png");
	SDL_Texture* textura_arbusto03 = window.loadTexture("res/Object/Bush (3).png");
	SDL_Texture* textura_placa01 = window.loadTexture("res/Object/Sign_1.png");
	SDL_Texture* textura_placa02 = window.loadTexture("res/Object/Sign_2.png");
	SDL_Texture* textura_cogumelo01 = window.loadTexture("res/Object/Mushroom_1.png");
	SDL_Texture* textura_cogumelo02 = window.loadTexture("res/Object/Mushroom_2.png");
	SDL_Texture* textura_pedra = window.loadTexture("res/Object/Stone.png");

	Entidade fundo = Entidade(Vector2f(-100,0), textura_fundo, 1880, 700, 0, 0);
	v.push_back(fundo);

	Entidade arvore01 = Entidade(Vector2f(800,250), textura_arvore02, 187, 200, 2, 0);
	v.push_back(arvore01);
	Entidade arbusto01 = Entidade(Vector2f(250,250), textura_arbusto01, 102, 50, 2, 0);
	v.push_back(arbusto01);

	Entidade grama01 = Entidade(Vector2f(500,450), textura_grama13, 150, 50, 2, 1);
	v.push_back(grama01);
	Entidade grama02 = Entidade(Vector2f(650,450), textura_grama14, 150, 50, 2, 1);
	v.push_back(grama02);
	Entidade grama03 = Entidade(Vector2f(800,450), textura_grama14, 150, 50, 2, 1);
	v.push_back(grama03);
	Entidade grama04 = Entidade(Vector2f(950,450), textura_grama15, 150, 50, 2, 1);
	v.push_back(grama04);

	Entidade grama05 = Entidade(Vector2f(100,300), textura_grama13, 150, 50, 2, 1);
	v.push_back(grama05);
	Entidade grama06 = Entidade(Vector2f(250,300), textura_grama14, 150, 50, 2, 1);
	v.push_back(grama06);
	Entidade grama07 = Entidade(Vector2f(400,300), textura_grama15, 150, 50, 2, 1);
	v.push_back(grama07);

	Entidade grama08 = Entidade(Vector2f(1000,250), textura_grama13, 150, 50, 2, 1);
	v.push_back(grama08);
	Entidade grama09 = Entidade(Vector2f(1150,250), textura_grama15, 150, 50, 2, 1);
	v.push_back(grama09);
}

int Mapa01::mostrarTela(){
	int currentTime = 0;
	int lastTime = 0;
	int mapa = 0;
	int estadoAnterior = mapa;
	bool executando = true;

	Vector2f posicao = Vector2f(800, 100);
	SDL_Texture* textura = window.loadTexture("res/gfx/personagem.png");
	
	Personagem prota = Personagem(posicao, textura, 110, 110, 2, 3, 100, 2);

	SDL_Event evento;
	while(executando){
		while(SDL_PollEvent(&evento)){
			if(evento.type == SDL_QUIT){
				executando = false;
			}
			if(evento.type == SDL_KEYDOWN && evento.key.keysym.sym == SDLK_ESCAPE){
				executando = false;
			}
		}

		currentTime = SDL_GetTicks();
		if(currentTime >= lastTime+3){
			prota.moverPersonagem(evento, &v);
			lastTime = currentTime;
		}

		window.clear();
		for(Entidade& e: v){
			window.render(e);
		}
		window.render(prota);
		
		if(prota.getPos().y > 800){
			executando = false;
		}
		window.display();
	}
	return 0;
}