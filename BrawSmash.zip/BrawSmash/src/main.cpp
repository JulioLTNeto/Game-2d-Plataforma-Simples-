#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <iostream>
#include <string>
#include <vector>

using namespace std;
#include "MostrarTela.hpp"
#include "Personagem.hpp"
#include "Math.hpp"
#include "Mapa01.hpp"
#include "Mapa02.hpp"

int main(int argc, char* args[]){
	if(SDL_Init(SDL_INIT_VIDEO) > 0){
		cout<< "SDL_INIT Fail Error:" << SDL_GetError()<< endl;
	}
	if(!(IMG_Init(IMG_INIT_PNG))){
		cout << "IMG_Init fail Error:" << SDL_GetError() << endl;
	}

	int currentTime = 0;
	int lastTime = 0;
	int mapa = 0;
	int estadoAnterior = mapa;

	vector<Entidade> entidades;

	MostrarTela window("BrawSmash", 1280, 700);
	bool executando = true;

	Vector2f posicao = Vector2f(800, 100);
	SDL_Texture* textura = window.loadTexture("res/gfx/personagem.png");
	
	Personagem prota = Personagem(posicao, textura, 110, 110, 2, 3, 100, 2);

	SDL_Event evento;
	while(executando){
		while(SDL_PollEvent(&evento)){
			if(evento.type == SDL_QUIT){
				executando = false;
			}
			if(evento.type == SDL_KEYDOWN && evento.key.keysym.sym == SDLK_ESCAPE){
				executando = false;
			}
		}

		if(mapa == 0){
			Mapa02 mapa2 = Mapa02();
			mapa2.gerarMapa(window);
			entidades = *(mapa2.getEntidades());
			estadoAnterior = mapa;
			mapa = -1;
		}
		if(mapa == 1){
			Mapa01 mapa1 = Mapa01();
			mapa1.gerarMapa();
			mapa = mapa1.mostrarTela();
			estadoAnterior = mapa;
			mapa = -1;
		}

		if(estadoAnterior == 0){
			if(evento.type == SDL_KEYDOWN){
				if(evento.key.keysym.sym == SDLK_UP){
					mapa = 1;
				}
			}
		}

		window.clear();
		for(Entidade& e: entidades){
			window.render(e);
		}
		if(estadoAnterior > 0){
			window.render(prota);
		}
		if(prota.getPos().y > 800){
			mapa = 0;
		}
		window.display();
	}
	window.cleanUp();
	SDL_Quit();
	return 0;
}